
lq8.net

- 探索丨https://dh.lq8.net

- 搜索丨https://so.lq8.net

六七八导航·AnYi-Navi丨世界的创新源于学术的探索

- 这是一个学术导航丨六七八导航致力于数字化资源的学术导航

- 代码由北邮人开源驱动，托管于Github页面。

- 由于静态页面原因，一些功能将在网站实行跳转呈现。

- 本人在修改及应用中，没有改变页面布局，只是将内容略作修缮。

- 今后一些页面将实行跳转到 六七八博客  https://www.lq8.net

AnYi-Navi
- The Navigation for AnYi ！ The Open source code comes from BYR·Navi：https://byr-navi.com/

Design Philosophy
- This project is a [Jekyll][jekyll]-powered website, which is built based on [Fomantic UI][fomantic] web framework, and deployed using [GitHub Pages][github-pages].

Last by
- Thank you and everyone. last thanks BYR-Navi. 
- by: ANYI's last modified.
      
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

Logo:

![AnYi-Navi](https://lq8.net/images/logo-dark.svg)

